# Ecommerce Database Design
The database is a core component for any dynamic system, In the Ecommerce
system there are several subsections that are enabled for running the whole
e-commerce system including user, admin, clients, products, delivery system,
etc, All parts need to maintain the information and also need to interconnect
between them. So A Relational database management system is compulsory for
this kind of system. Whatsoever, For many other privileges and accessibility, I
chose MySQL as the database management system.

Nowadays E-Commerce is one of the hot topics. So I chose this topic to provide a database design for this. In this RDBMS project, I was trying to provide a concept and mid-range to a practical approach to design a Database System that can serve an E-Commerce System.

